package com.example.admin.newsbytes.SessionLayer;

import com.example.admin.newsbytes.Messenger;
import com.example.admin.newsbytes.Newsletter;
import com.example.admin.newsbytes.User;
import com.example.admin.newsbytes.UserLog;

import java.util.List;

/**
 * Created by Admin on 4/20/2018.
 */

public class Track {

    List<Messenger> list_of_sentMessages;


    public static Messenger formAMessage(User user)
    {
        Messenger messenger = new Messenger();
        messenger.header="User header";
        messenger.type=user.typeOfValidation;
        messenger.object=user;

        return messenger;
    }

    public static Messenger formAMessage(UserLog log)
    {
        Messenger messenger = new Messenger();
        messenger.header="User header";
        messenger.type="log";
        messenger.object=(UserLog)log;

        return messenger;
    }

    public static  Newsletter deserialiseAMessage(Messenger messenger)
    {
        Newsletter newsletter = new Newsletter();
//        if(messenger.type=="News")
//        {
            newsletter = (Newsletter)messenger.object;
//        }
//
        return newsletter;
    }





}
