package com.example.admin.newsbytes;

import android.app.LauncherActivity;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.admin.newsbytes.TranportLayer.ConnectionUtility;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;


public class MainActivity extends AppCompatActivity {

//
//    private RecyclerView recyclerView;
//    private RecyclerView.Adapter adapter;
    TrackableMessenger messenger;

//    private List<ListItem> listItems;

    GlobalShare globalShare;
    Button login ;
    Button  register ;
    EditText username;
    EditText password;
    private static Socket s;
    private static Socket s2;
    private static ServerSocket ss;
    private static InputStreamReader isr;
    private static BufferedReader br;
    private static PrintWriter printWriter;
    private BufferedReader in = null;
    String message ;
    String userid;
    String pwd;
    private  static String ip = "10.0.2.2";
    private static ObjectOutputStream out;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        messenger = new TrackableMessenger();
        globalShare = new GlobalShare();
        login = (Button)findViewById(R.id.login);
        register = (Button)findViewById(R.id.register);
        username = (EditText)findViewById(R.id.username);
        password = (EditText)findViewById(R.id.password);
        Context ctx = this;
//        recyclerView = (RecyclerView)findViewById(R.id.recyclerview);
//        recyclerView.setHasFixedSize(true);
//        recyclerView.setLayoutManager(new LinearLayoutManager(this));
//        listItems = new ArrayList<>();
//
//        for(int i = 1 ; i <=10 ;i++)
//        {
//            ListItem item = new ListItem("head "+ i , " desriptions");
//            listItems.add(item);
//        }
//
//        adapter = new MyAdapter(listItems,this);
//        recyclerView.setAdapter(adapter);


        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                    verifyLogin(v);

//                Intent intent;
//                intent = new Intent(getBaseContext(),testing_tabs.class);
//                startActivity(intent);




            }
        });



        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent;
                intent = new Intent(v.getContext(),register_user.class);
                startActivity(intent);


//                User user = new User();
//                user.setUsername(username.toString());
//                user.setPassword(password.toString());
//                messenger.sendMessage(user.giveMessage());
//                Toast.makeText(getApplicationContext(), "Message Sent ", Toast.LENGTH_LONG).show();




            }
        });

    }






    public void sendText(View v)
    {
        message = username.getText().toString();
        pwd =password.getText().toString();
        TestConnection tc = new TestConnection();
        tc.execute();
        Toast.makeText(getApplicationContext(), "Message Sent ", Toast.LENGTH_LONG).show();

    }


    public Newsletter verifyLogin(View v)
    {
        Newsletter list_of_news = new Newsletter() ;
        message = username.getText().toString();
        pwd =password.getText().toString();
        User user = new User();
        user.userid = message;
        user.password = pwd;
        user.typeOfValidation="login";
        if(user.userid.isEmpty()||user.password.isEmpty())
        {
            Toast.makeText(getBaseContext(),"Enter Full details",Toast.LENGTH_LONG).show();
        }
        else {
            ConnectToServer cts = new ConnectToServer();
            cts.execute(user);
        }
        return list_of_news;
    }

    public void registerUser(View v)
    {

    }

//    class TestConnection extends AsyncTask<User,Void,Void>
//    {
//
//        @Override
//        protected Void doInBackground(User... users) {
//
//            Message message = new Message();
//            message.body = users[0];
//            messenger.sendMessage(message);
//
//            return null;
//        }
//
//        @Override
//        protected void onPreExecute() {
//            super.onPreExecute();
//        }
//
//        @Override
//        protected void onPostExecute(Void aVoid) {
//            super.onPostExecute(aVoid);
//
//        }
//    }

    class TestConnection extends AsyncTask<Void,Void,Void>
    {

        @Override
        protected Void doInBackground(Void... voids) {
            try {

                s = new Socket(ip, 5011);

                TMessage objm = new TMessage();
                objm.TYPE = 1;
                objm.ID = 2;
                //objm.DATA=message;
                objm.username = message;
               // objm.password=password;
                //System.out.print(objm);
                ObjectOutputStream oos = new ObjectOutputStream(s.getOutputStream());
                oos.writeObject(objm);

                oos.flush();

                ObjectInputStream ois_readMessage = new ObjectInputStream(s.getInputStream());
                //TMessage obj_message_read = new TMessage();

                Newsletter obj_message_read = new Newsletter();
                System.out.println("A new client is connected : " + s);
                while(s.isConnected()) {
                    System.out.println("here");
                    Object aux = ois_readMessage.readObject();
                    if (aux instanceof Newsletter) {
                        obj_message_read = (Newsletter) aux;
                        System.out.println(obj_message_read);
                        //  System.out.println(obj_message_read.DATA);
//                      setTYPE(obj_message_read.TYPE);
//                      setID(obj_message_read.ID);
                        System.out.println("Data from client : " + obj_message_read.news);
////                        ArrayAdapter<String> mHistory = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1);
////                        newslist.setAdapter(mHistory);
                        int arraySize = obj_message_read.news.size();
                        for (int i = 0; i < arraySize; i++) {
                            News obj= obj_message_read.news.get(i);
                            ListItem item = new ListItem(obj.headlines.toString(),obj.description.toString());
                            globalShare.populate(item);
                           // messageFromServer.append(obj.headlines);
                            //messageFromServer.append(obj.description);
                            //messageFromServer.append("\n");
                            //myTextView.append(obj_message_read.newsletter[i]);
                        }
                        s.close();
                        // messageFromServer.setText(obj_message_read.newsletter[0]);
                    }
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
            catch(ClassNotFoundException c)
            {
                c.printStackTrace();
            }

            return null;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);

        }
    }






    class ConnectToServer extends AsyncTask<User,Newsletter,Newsletter>
    {


        @Override
        protected void onPostExecute(Newsletter newsletter) {
            super.onPostExecute(newsletter);
            if(newsletter.news.size()>0)
            {
                Toast.makeText(getBaseContext(),"Successfully logged in",Toast.LENGTH_LONG).show();
                Intent intent;
                intent = new Intent(getBaseContext(),testing_tabs.class);
                intent.putExtra("NewsLetter",newsletter);
                startActivity(intent);
            }
            else
            {
                Toast.makeText(getBaseContext(),"Invalid Username or Password",Toast.LENGTH_LONG).show();

            }


        }

        @Override
        protected Newsletter doInBackground(User... users) {
            ConnectionUtility connectionUtility = new ConnectionUtility();
            connectionUtility.sendUserDetailsToServer(users[0]);
            Newsletter letter = connectionUtility.getNewsLetterFromServer();

            return letter;
        }
    }
}
