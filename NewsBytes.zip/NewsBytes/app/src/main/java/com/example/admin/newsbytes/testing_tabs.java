package com.example.admin.newsbytes;

import android.content.Intent;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.example.admin.newsbytes.TranportLayer.ViewPagerAdapter;

import java.util.ArrayList;
import java.util.List;

public class testing_tabs extends AppCompatActivity {

    private TabLayout tabLayout;
    private ViewPager viewPager;
    private ViewPagerAdapter adapter;

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        Intent intent;
        intent = new Intent(getBaseContext(),MainActivity.class);

        startActivity(intent);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_testing_tabs);

        tabLayout = (TabLayout)findViewById(R.id.tablayout_id);
        viewPager = (ViewPager)findViewById(R.id.viewpager_id);
        adapter = new ViewPagerAdapter(getSupportFragmentManager());

        Newsletter info = (Newsletter) getIntent().getSerializableExtra("NewsLetter");
        List<ListItem> listItems = new ArrayList<>() ;
        List<News> news = info.news;
        GeneralNews gn = new GeneralNews();
        RecommendedNews rn = new RecommendedNews();
        for(News n : news)
        {
            ListItem li = new ListItem(n.headlines,n.description);
            listItems.add(li);
        }
        List<Integer> indexes = info.listofrecommendedindexes;
        List<ListItem> recommend = new ArrayList<>() ;
        if(indexes!= null) {
            for (Integer i : indexes) {
                News n = news.get(i);
                ListItem li = new ListItem(n.headlines, n.description);
                if(!recommend.contains(li))
                   recommend.add(li);
            }
        }
        gn.listItems = info.news;
        gn.userid = info.userid;
        rn.listItems = recommend;
        adapter.AddFragment(gn,"General News ");
        adapter.AddFragment(rn,"Your Recommendations");

        viewPager.setAdapter(adapter);
        tabLayout.setupWithViewPager(viewPager);
    }
}
