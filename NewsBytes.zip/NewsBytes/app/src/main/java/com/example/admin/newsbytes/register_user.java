package com.example.admin.newsbytes;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.admin.newsbytes.TranportLayer.ConnectionUtility;

public class register_user extends AppCompatActivity {

    Button save_details;
    EditText username;
    EditText password;
    EditText email;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_user);
        username = (EditText)findViewById(R.id.newusername);
        password = (EditText)findViewById(R.id.newpassword);
        email = (EditText)findViewById(R.id.newemailaddress);
        save_details = (Button)findViewById(R.id.saveuserdetails);


        save_details.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

//                Intent intent;
//                intent = new Intent(getBaseContext(),testing_tabs.class);
//                startActivity(intent);
                User newuser = new User();
                newuser.userid = username.getText().toString();
                newuser.password = password.getText().toString();
                newuser.useremail = email.getText().toString();
                newuser.typeOfValidation="signup";
                if(newuser.userid.isEmpty() || newuser.password.isEmpty())
                    Toast.makeText(getBaseContext(),"Enter Full details",Toast.LENGTH_LONG).show();
                else {
                    ConnectToServerToCreateUser connectToServerToCreateUser = new ConnectToServerToCreateUser();
                    connectToServerToCreateUser.execute(newuser);
                }




            }
        });

    }



    class ConnectToServerToCreateUser extends AsyncTask<User,Newsletter,Newsletter>
    {


        @Override
        protected void onPostExecute(Newsletter newsletter) {
            super.onPostExecute(newsletter);
            Intent intent;
            intent = new Intent(getBaseContext(),testing_tabs.class);
            intent.putExtra("NewsLetter",newsletter);
            startActivity(intent);

        }

        @Override
        protected Newsletter doInBackground(User... users) {
            ConnectionUtility connectionUtility = new ConnectionUtility();
            connectionUtility.sendUserDetailsToServer(users[0]);
            Newsletter letter = connectionUtility.getNewsLetterFromServer();
            return letter;
        }
    }
}
