package com.example.admin.newsbytes;

import java.io.Serializable;

/**
 * Created by Admin on 4/20/2018.
 */

public class UserLog implements Serializable{

   public int userid;
    public int newsid;

}
