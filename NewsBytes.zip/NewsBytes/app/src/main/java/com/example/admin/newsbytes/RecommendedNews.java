package com.example.admin.newsbytes;

import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Admin on 4/19/2018.
 */

public class RecommendedNews extends Fragment {

    View v;
    private RecyclerView recyclerView;
    public List<ListItem> listItems;

    public RecommendedNews()
    {
        listItems = populateDummy();

    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        v = inflater.inflate(R.layout.test_recycle,container,false);
        recyclerView = (RecyclerView)v.findViewById(R.id.recyclerview);
        MyAdapter adapter= new MyAdapter(listItems,getContext());
        //recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        recyclerView.setAdapter(adapter);
//        recyclerView.setHasFixedSize(true);
//        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        listItems = new ArrayList<>();

//        for(int i = 1 ; i <=30 ;i++)
//        {
//            ListItem item = new ListItem(" "+ i , " desriptions");
//            listItems.add(item);
//        }






//        adapter = new MyAdapter(listItems,this);
//        recyclerView.setAdapter(adapter);
        return v;
    }


    public  List<ListItem> populateDummy()
    {
        List<ListItem> ans = new ArrayList<>();
        ListItem one = new ListItem("Special news","New News");
        ans.add(one);
        ListItem two = new ListItem("Special news","England stnds Ird at CWG");
        ans.add(two);
        ListItem third = new ListItem("Protest march at India Gate","gatger jshdshdsadhlhdl.D");
        ans.add(third);
        ListItem fou = new ListItem("JEE Exams","Examins begins");
        ans.add(one);
        ListItem fi = new ListItem("Sports news","India stnds 3rd at CWG");
        ans.add(fi);
        ListItem six = new ListItem("Sports news","India stnds 3rd at CWG");
        ans.add(six);
        ListItem se = new ListItem("History Of India","India's history");

        ans.add(se);


        return ans;
    }
}
