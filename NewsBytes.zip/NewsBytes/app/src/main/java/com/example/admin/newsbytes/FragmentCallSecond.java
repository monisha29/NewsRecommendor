package com.example.admin.newsbytes;

import android.app.Fragment;

/**
 * Created by Admin on 4/18/2018.
 */

public class FragmentCallSecond extends android.support.v4.app.Fragment {
}
