package com.example.admin.newsbytes;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Admin on 4/19/2018.
 */

public  class GlobalShare {
  public static  List<ListItem> general_list;

    public GlobalShare()
    {
        general_list = new ArrayList<>();
    }

    public void populate(ListItem item)
    {
        general_list.add(item);
    }



    public static List<ListItem> getInstance()
    {


        return general_list;
    }

}
