package com.example.admin.newsbytes;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.admin.newsbytes.TranportLayer.ConnectionUtility;

public class news_details extends AppCompatActivity {

    TextView headline ;
    TextView desc ;
    ImageView img;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news_details);
        headline =(TextView)findViewById(R.id.newsdetailshead);
        desc =(TextView)findViewById(R.id.newsdetailsdesc);
        img = (ImageView)findViewById(R.id.img);
        headline.setText(getIntent().getStringExtra("headline"));
        desc.setText(getIntent().getStringExtra("desc"));
        UserLog log = new UserLog();
        log.userid = getIntent().getIntExtra("userid",0);
        log.newsid = getIntent().getIntExtra("newsid",0);
        ConnectToServer connectToServer = new ConnectToServer();
        connectToServer.execute(log);
    }



    class ConnectToServer extends AsyncTask<UserLog,Void,Void>
    {



        @Override
        protected Void doInBackground(UserLog... users) {
            ConnectionUtility connectionUtility = new ConnectionUtility();
            connectionUtility.sendUserLogToServer(users[0]);


            return null;
        }
    }


}
