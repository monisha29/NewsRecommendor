package com.example.admin.newsbytes;


import com.example.admin.newsbytes.Message;

import java.io.Serializable;

public class User implements Serializable {

	
   public String userid;
   public String password;
   public String useremail;
   public String typeOfValidation;
	

	
	
	
	
	
	
	
	
	

}
