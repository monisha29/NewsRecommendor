package com.example.admin.newsbytes.TranportLayer;

import com.example.admin.newsbytes.Messenger;
import com.example.admin.newsbytes.Newsletter;
import com.example.admin.newsbytes.SessionLayer.Track;
import com.example.admin.newsbytes.User;
import com.example.admin.newsbytes.UserLog;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;

/**
 * Created by Admin on 4/20/2018.
 */

public class ConnectionUtility {

    private static Socket s;
    private  static String ip = "10.0.2.2";
    ObjectOutputStream oos;
    ObjectInputStream ois;

    public ConnectionUtility()
    {
        try {
            s = new Socket(ip, 5011);
            oos = new ObjectOutputStream(s.getOutputStream());
            ois = new ObjectInputStream(s.getInputStream());
        }
        catch (Exception e)
        {

        }
    }


    public void sendUserDetailsToServer(User user)
    {
        com.example.admin.newsbytes.Messenger msg = new com.example.admin.newsbytes.Messenger();
        try {
            msg = Track.formAMessage(user);
            oos.writeObject(msg);
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public void sendUserDetailsToServer(UserLog user)
    {
        com.example.admin.newsbytes.Messenger msg = new com.example.admin.newsbytes.Messenger();
        try {
            msg = Track.formAMessage(user);
            msg.type = "login";
            oos.writeObject(msg);
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    public void sendUserLogToServer(UserLog user)
    {
        com.example.admin.newsbytes.Messenger msg = new com.example.admin.newsbytes.Messenger();
        try {
            msg = Track.formAMessage(user);
            msg.type = "log";
            oos.writeObject(msg);
            Messenger a = (Messenger)ois.readObject();
        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }

    }
    public Newsletter getNewsLetterFromServer()
    {
        Newsletter newsletter = null;
        try {
            Messenger aux =(Messenger) ois.readObject();
            newsletter = Track.deserialiseAMessage(aux);


        } catch (IOException e) {
            e.printStackTrace();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        }


        return newsletter;
    }





}

