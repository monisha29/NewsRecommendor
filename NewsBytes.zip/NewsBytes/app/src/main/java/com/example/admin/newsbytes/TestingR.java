package com.example.admin.newsbytes;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class TestingR extends AppCompatActivity {


    private RecyclerView recyclerView;
    private RecyclerView.Adapter adapter;


    private List<ListItem> listItems;





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_testing_r);
        recyclerView = (RecyclerView)findViewById(R.id.recyclerview);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        listItems = new ArrayList<>();

//        for(int i = 1 ; i <=30 ;i++)
//        {
//            ListItem item = new ListItem(" "+ i , " desriptions");
//            listItems.add(item);
//        }
        listItems = populateDummy();






        adapter = new MyAdapter(listItems,this);
        recyclerView.setAdapter(adapter);

    }



    public  List<ListItem> populateDummy()
    {
        List<ListItem> ans = new ArrayList<>();
        ListItem one = new ListItem("Sports news","India stnds 3rd at CWG");
        ans.add(one);
        ListItem two = new ListItem("Sports news","England stnds Ird at CWG");
        ans.add(two);
        ListItem third = new ListItem("Protest march at India Gate","gatger jshdshdsadhlhdl.D");
        ans.add(third);
        ListItem fou = new ListItem("JEE Exams","Examins begins");
        ans.add(one);
        ListItem fi = new ListItem("Sports news","India stnds 3rd at CWG");
        ans.add(fi);
        ListItem six = new ListItem("Sports news","India stnds 3rd at CWG");
        ans.add(six);
        ListItem se = new ListItem("Sports news","India stnds 3rd at CWG");
        ans.add(se);
        ListItem ei = new ListItem("Sports news","India stnds 3rd at CWG");
        ans.add(ei);
        ListItem non = new ListItem("Sports news","India stnds 3rd at CWG");
        ans.add(non);
        ListItem oe = new ListItem("Sports news","India stnds 3rd at CWG");
        ans.add(oe);
        ListItem tone = new ListItem("Sports news","India stnds 3rd at CWG");
        ans.add(tone);
        ListItem f = new ListItem("Sports news","India stnds 3rd at CWG");
        ans.add(f);
        ListItem done = new ListItem("Sports news","India stnds 3rd at CWG");
        ans.add(done);
        ListItem odne = new ListItem("Sports news","India stnds 3rd at CWG");
        ans.add(odne);


        return ans;
    }
}
