package com.example.admin.newsbytes;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Admin on 4/20/2018.
 */

public class NewsAdapter extends RecyclerView.Adapter<NewsAdapter.ViewHolder>{




    private List<News> listItems;
    private Context context;
    private int userid;

    public NewsAdapter(List<News> listItems, Context context,int userid) {
        this.listItems = listItems;
        this.context = context;
        this.userid = userid;
    }

    @Override
    public NewsAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.list_item,parent,false);
        return new NewsAdapter.ViewHolder(v,context,listItems);
    }



    @Override
    public void onBindViewHolder(NewsAdapter.ViewHolder holder, int position) {
        final News listItem = listItems.get(position);
        holder.head.setText(listItem.headlines);
        holder.desc.setText(listItem.description);

//        holder.linearlayout.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//                Toast.makeText(context,"ou clicked " + listItem.getHead(), Toast.LENGTH_LONG).show();
//                Intent intent;
//                intent = new Intent(context,TestingR.class);
//                //startActivity(intent);
//            }
//        });
    }

    @Override
    public int getItemCount() {
        return listItems.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{

        public TextView head ;
        public  TextView desc;
        public ImageView img;
        public LinearLayout linearlayout;
        List<News> listItems_new  =new ArrayList<>();
        Context ctx ;
        public ViewHolder(View itemView,Context ctx , List<News> items) {
            super(itemView);
            listItems_new = items;
            this.ctx = ctx;
            itemView.setOnClickListener(this);
            head = (TextView)itemView.findViewById(R.id.textViewHead);
            desc = (TextView)itemView.findViewById(R.id.description);
            //  img = (ImageView)itemView.findViewById(R.id.imageView);
            linearlayout = (LinearLayout)itemView.findViewById(R.id.LinearLayout);
        }

        @Override
        public void onClick(View v) {
            int position = getAdapterPosition();
            News listItem = this.listItems_new.get(position);
            Intent intent = new Intent(ctx,news_details.class);
            intent.putExtra("newsid",position);
            intent.putExtra("userid",userid);
            intent.putExtra("headline" ,listItem.headlines);
            intent.putExtra("desc",listItem.description);
            this.ctx.startActivity(intent);

        }
    }
}
