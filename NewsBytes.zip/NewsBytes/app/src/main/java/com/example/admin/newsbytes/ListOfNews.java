package com.example.admin.newsbytes;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

public class ListOfNews extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list_of_news);
    }
}
