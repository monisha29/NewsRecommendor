package com.example.admin.newsbytes.TranportLayer;

import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;

import com.example.admin.newsbytes.FragmentCall;
import com.example.admin.newsbytes.GeneralNews;
import com.example.admin.newsbytes.RecommendedNews;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by Admin on 4/18/2018.
 */

public class ViewPagerAdapter extends FragmentPagerAdapter {

    private final List<Fragment> lstFragment = new ArrayList<>();
    private final List<String> lstTiles = new ArrayList<>();


    @Override
    public CharSequence getPageTitle(int position) {
        return lstTiles.get(position);
    }


//    public  void AddFragment(FragmentCall fragment, String title)
//    {
//        lstFragment.add(fragment);
//        lstTiles.add(title);
//    }
    public  void AddFragment(GeneralNews fragment, String title)
    {
        lstFragment.add(fragment);
        lstTiles.add(title);
    }

    public  void AddFragment(RecommendedNews fragment, String title)
    {
        lstFragment.add(fragment);
        lstTiles.add(title);
    }

    @Override
    public int getCount() {
        return lstTiles.size();
    }

    @Override
    public Fragment getItem(int position) {
        return lstFragment.get(position);
    }

    public ViewPagerAdapter(FragmentManager fm) {
        super(fm);
    }
}
