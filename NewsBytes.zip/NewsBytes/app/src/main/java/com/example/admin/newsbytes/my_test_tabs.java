package com.example.admin.newsbytes;

import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;

import com.example.admin.newsbytes.TranportLayer.ViewPagerAdapter;

/**
 * Created by Admin on 4/18/2018.
 */

public class my_test_tabs {




}
