package com.example.admin.newsbytes;

/**
 * Created by Admin on 4/19/2018.
 */

import java.io.Serializable;
import java.util.List;

/**
 * Created by Admin on 4/18/2018.
 */

public class News implements Serializable {
    public int newsId;
    public String headlines;
    public String description;
//    public  String imageurl;
//    public String newsurl;
//    public List<String> newsprofile;




}