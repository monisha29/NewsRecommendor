package com.example.admin.newsbytes.TranportLayer;

import android.os.AsyncTask;
import android.widget.Toast;

import java.io.IOException;
import java.io.ObjectOutputStream;
import java.net.Socket;

import com.example.admin.newsbytes.Message;

/**
 * Created by Admin on 3/30/2018.
 */

public class TransportHandle {
    private static Socket s;
    private  static String ip = "10.0.2.2";

    public void send(Message msg)
    {
        try {
            TestConnection tc = new TestConnection();
            tc.execute();

        }
        catch(Exception e)
        {
            e.printStackTrace();
        }
    }


    class TestConnection extends AsyncTask<Message,Void,Void>
    {

        @Override
        protected Void doInBackground(Message... voids) {
            try {
                s=new Socket(ip,5011);
                ObjectOutputStream salida_mensaje = new ObjectOutputStream(s.getOutputStream());
                Message message = voids[0];
                salida_mensaje.writeObject(message);
                salida_mensaje.flush();
                s.close();
            } catch (IOException e) {
                e.printStackTrace();
            }


            return null;
        }

        @Override
        protected void onPreExecute() {
            super.onPreExecute();
        }

        @Override
        protected void onPostExecute(Void aVoid) {
            super.onPostExecute(aVoid);

        }
    }

}
