package com.example.admin.newsbytes;

import com.example.admin.newsbytes.TranportLayer.TransportHandle;

import java.util.HashMap;

/**
 * Created by Admin on 3/29/2018.
 */

public class TrackableMessenger {
int last_processed_id = 0;
    TransportHandle th ;




    public void sendMessage(Message message)
    {
        th = new TransportHandle();
        message.header = new HashMap<String, Object>();
      message.header.put("last_processed_id",(Integer)last_processed_id);
      th.send(message);

    }


    public byte[] serialize(Message msg)
    {
        String change = msg.body.toString();
        System.out.println(" Server sends  " + change);
        return change.getBytes();
    }

    private static Message deserialize(byte[] data)
    {
        //System.out.println("here :" + data);
        Message msg = new Message();
        String covert = new String(data);
        System.out.println(covert);
        msg.body = new String(covert);
        return msg;
    }


}
